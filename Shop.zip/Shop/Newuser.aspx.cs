﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Cart
{

    public partial class Newuser : System.Web.UI.Page
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;


        protected void Page_Load(object sender, EventArgs e)
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            con = new SqlConnection(conStr);

            //con = new SqlConnection();
            //con.ConnectionString = conStr; 
            cmd = new SqlCommand();
            cmd.CommandText = "MyCart_161.USPCreateAcc";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;



            cmd.Parameters.AddWithValue("@uname", txtforuname.Text);
            cmd.Parameters.AddWithValue("@pass", txtforpassword.Text);
            cmd.Parameters.AddWithValue("@securityques", ddlforsecurityques.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@securityans", txtforanswer.Text);


            con.Open();
            int noOfRowsAffected = cmd.ExecuteNonQuery();
            
        }
    }
}
